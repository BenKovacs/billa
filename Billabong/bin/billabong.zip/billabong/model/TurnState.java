package billabong.model;

public enum TurnState {
	Idle, MovesFound, DepthComplete
}
