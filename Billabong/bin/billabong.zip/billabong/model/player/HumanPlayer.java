package billabong.model.player;

public class HumanPlayer extends Player {

	@Override
	public void move() {
		// TODO Implement human player movement 
	}

}
